function setup() {
  createCanvas(400, 500);
  background(220);
}

function draw() {
  background(220);
}
